/**
 * ZACMO Splash Screen Controller
 * Shows once per browser session (sessionStorage), then hides itself.
 * Respects a theme-editor "always show" toggle for merchant previewing.
 */
(function () {
  var SESSION_KEY = "zacmo_splash_shown";

  function initSplash() {
    var splash = document.querySelector("[data-zacmo-splash]");
    if (!splash) return;

    var alwaysShow = splash.getAttribute("data-always-show") === "true";
    var minDuration = parseInt(splash.getAttribute("data-min-duration"), 10) || 1200;

    var alreadyShown = false;
    try {
      alreadyShown = sessionStorage.getItem(SESSION_KEY) === "1";
    } catch (e) {
      // sessionStorage unavailable (privacy mode) — fall back to always showing once per page load
      alreadyShown = false;
    }

    if (alreadyShown && !alwaysShow) {
      splash.setAttribute("hidden", "");
      document.body.classList.remove("zacmo-splash-active");
      return;
    }

    document.body.classList.add("zacmo-splash-active");

    var start = Date.now();
    var dismiss = function () {
      var elapsed = Date.now() - start;
      var wait = Math.max(minDuration - elapsed, 0);
      setTimeout(function () {
        splash.setAttribute("hidden", "");
        document.body.classList.remove("zacmo-splash-active");
        try {
          sessionStorage.setItem(SESSION_KEY, "1");
        } catch (e) {}
      }, wait);
    };

    if (document.readyState === "complete") {
      dismiss();
    } else {
      window.addEventListener("load", dismiss, { once: true });
    }

    // Allow click-to-skip
    splash.addEventListener("click", function () {
      splash.setAttribute("hidden", "");
      document.body.classList.remove("zacmo-splash-active");
      try {
        sessionStorage.setItem(SESSION_KEY, "1");
      } catch (e) {}
    });
  }

  if (document.readyState !== "loading") {
    initSplash();
  } else {
    document.addEventListener("DOMContentLoaded", initSplash);
  }
})();
