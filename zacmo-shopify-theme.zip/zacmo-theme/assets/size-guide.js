(function () {
  "use strict";
  document.addEventListener("click", function (e) {
    var btn = e.target.closest("[data-zacmo-tab-target]");
    if (!btn) return;
    var wrapper = btn.closest(".size-guide-section");
    if (!wrapper) return;

    var targetId = btn.getAttribute("data-zacmo-tab-target");

    wrapper.querySelectorAll(".size-guide-tab").forEach(function (tab) {
      tab.classList.toggle("is-active", tab === btn);
    });
    wrapper.querySelectorAll(".size-guide-panel").forEach(function (panel) {
      panel.classList.toggle("is-active", panel.id === targetId);
    });
  });
})();
