/**
 * ZACMO Product Configurator
 * Handles: variant selection -> 3D model swap, tech-spec refresh,
 * price update, and add-to-cart variant id sync.
 * Multiple instances (multiple sections on a page) are supported via section id scoping.
 */
(function () {
  "use strict";

  function formatMoney(cents) {
    // Basic fallback formatter; Shopify's own money format is already
    // baked into the "price" string coming from Liquid, so this is
    // only used if a numeric compare-at price needs formatting.
    if (typeof cents !== "number") return "";
    return (cents / 100).toFixed(2);
  }

  function initConfigurator(root) {
    var sectionId = root.id.replace("ProductConfigurator-", "");

    var dataScript = document.getElementById("ZacmoVariantData-" + sectionId);
    if (!dataScript) return;

    var data;
    try {
      data = JSON.parse(dataScript.textContent).variants;
    } catch (e) {
      console.error("ZACMO configurator: could not parse variant data", e);
      return;
    }

    var modelViewer = document.getElementById("ZacmoModelViewer-" + sectionId);
    var priceEl = document.getElementById("ZacmoPrice-" + sectionId);
    var variantIdInput = document.getElementById("ZacmoVariantId-" + sectionId);
    var addBtn = document.getElementById("ZacmoAddBtn-" + sectionId);
    var techSpecs = document.getElementById("ZacmoTechSpecs-" + sectionId);
    var picker = root.querySelector("[data-zacmo-variant-picker]");

    if (!picker) return;

    var swatches = Array.prototype.slice.call(
      picker.querySelectorAll("[data-zacmo-option-value]")
    );

    // Track currently selected option values, seeded from whatever is marked active.
    var selectedOptions = [];
    picker.querySelectorAll(".variant-picker__option").forEach(function (optionEl, i) {
      var activeBtn = optionEl.querySelector(".is-active");
      selectedOptions[i] = activeBtn ? activeBtn.getAttribute("data-zacmo-option-value") : null;
    });

    function findMatchingVariant() {
      return data.find(function (variant) {
        return variant.options.every(function (val, idx) {
          return selectedOptions[idx] == null || val === selectedOptions[idx];
        });
      });
    }

    function updateModel(variant) {
      if (!modelViewer) return;
      if (variant.model_3d_url) {
        modelViewer.setAttribute("src", variant.model_3d_url);
        if (variant.poster_url) modelViewer.setAttribute("poster", variant.poster_url);
        modelViewer.style.display = "";
      } else {
        // No 3D model for this variant — fall back gracefully to the 2D image.
        modelViewer.removeAttribute("src");
        var fallbackImg = modelViewer.querySelector("img[data-zacmo-fallback]");
        if (!fallbackImg) {
          fallbackImg = document.createElement("img");
          fallbackImg.setAttribute("data-zacmo-fallback", "");
          fallbackImg.style.cssText = "width:100%;height:100%;object-fit:contain;position:absolute;inset:0;";
          modelViewer.parentElement.style.position = "relative";
          modelViewer.parentElement.appendChild(fallbackImg);
        }
        fallbackImg.src = variant.featured_image || modelViewer.getAttribute("data-fallback-image");
        fallbackImg.style.display = "block";
        return;
      }
      var existingFallback = modelViewer.parentElement.querySelector("img[data-zacmo-fallback]");
      if (existingFallback) existingFallback.style.display = "none";
    }

    function flash(el) {
      if (!el) return;
      el.classList.remove("is-updated");
      // Force reflow so the animation can retrigger
      void el.offsetWidth;
      el.classList.add("is-updated");
    }

    function updateTechSpecs(variant) {
      if (!techSpecs) return;
      var map = {
        gsm: variant.gsm,
        fabric_type: variant.fabric_type,
        fit: variant.fit,
        care: variant.care
      };
      Object.keys(map).forEach(function (key) {
        var el = techSpecs.querySelector('[data-zacmo-spec="' + key + '"]');
        if (!el) return;
        var newValue = key === "gsm" ? map[key] + " GSM" : map[key];
        if (el.textContent.trim() !== String(newValue).trim()) {
          el.textContent = newValue;
          flash(el.closest("td") || el);
        }
      });
    }

    function updatePriceAndCart(variant) {
      if (priceEl) priceEl.textContent = variant.price;
      if (variantIdInput) variantIdInput.value = variant.id;
      if (addBtn) {
        addBtn.disabled = !variant.available;
        addBtn.textContent = variant.available ? "Add to Bag" : "Sold Out";
      }
    }

    function updateSwatchStates() {
      swatches.forEach(function (btn) {
        var idx = parseInt(btn.getAttribute("data-zacmo-option-index"), 10);
        var val = btn.getAttribute("data-zacmo-option-value");
        btn.classList.toggle("is-active", selectedOptions[idx] === val);
      });
    }

    function applyVariant(variant) {
      if (!variant) return;
      updateModel(variant);
      updateTechSpecs(variant);
      updatePriceAndCart(variant);

      // Update the URL so the selected variant is shareable/bookmarkable.
      if (window.history && window.history.replaceState) {
        var url = new URL(window.location.href);
        url.searchParams.set("variant", variant.id);
        window.history.replaceState({}, "", url);
      }
    }

    swatches.forEach(function (btn) {
      btn.addEventListener("click", function () {
        var idx = parseInt(btn.getAttribute("data-zacmo-option-index"), 10);
        selectedOptions[idx] = btn.getAttribute("data-zacmo-option-value");
        updateSwatchStates();
        var match = findMatchingVariant();
        applyVariant(match);
      });
    });

    // Initialize model/specs to whatever variant is currently selected server-side.
    var initial = findMatchingVariant();
    if (initial) applyVariant(initial);
  }

  function initAll() {
    document.querySelectorAll('[id^="ProductConfigurator-"]').forEach(initConfigurator);
  }

  if (document.readyState !== "loading") {
    initAll();
  } else {
    document.addEventListener("DOMContentLoaded", initAll);
  }

  // Re-init if Shopify's theme editor re-renders the section.
  document.addEventListener("shopify:section:load", function (evt) {
    var root = evt.target.querySelector('[id^="ProductConfigurator-"]');
    if (root) initConfigurator(root);
  });
})();
